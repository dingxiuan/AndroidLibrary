/*
 * Copyright 2016 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.spring.influxdb;

import io.reactivex.schedulers.Schedulers;
import org.apache.commons.io.IOUtils;
import org.influxdb.dto.Query;
import org.influxdb.dto.QueryResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.influxdb.enable.EnableAutoInfluxDBConfiguration;
import org.springframework.data.influxdb.query.SimpleValueConverter;
import org.springframework.data.influxdb.template.rx.QuerySubscriber;
import org.springframework.data.influxdb.template.rx.RxInfluxDBTemplate;
import org.springframework.scheduling.annotation.EnableScheduling;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

@EnableScheduling
@EnableAutoInfluxDBConfiguration
@SpringBootApplication
public class Application implements CommandLineRunner {
    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);

//        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
//        System.err.println(sdf.format(1543318471000L));
    }

    @Autowired
    private RxInfluxDBTemplate template;

    private static final ThreadLocal<SimpleDateFormat> FORMATTER_MILLIS = ThreadLocal.withInitial(() -> new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"));

    private String fmt(Object time) {
        return FORMATTER_MILLIS.get().format(time);
    }

    @Override
    public void run(final String... args) {
        // Create database...
//        template.createDatabase();

        startQuery();
    }

    private void startQuery() {
        final AtomicLong counter = new AtomicLong(0);
        final StringBuffer buffer = new StringBuffer();
        long startTime = now();
        String sql = "SELECT heart_rate AS point FROM hs_all_rates WHERE device_id = '00000380'";
        Query query = new Query(sql, template.getDatabase());
        template.query(query, 10000)
                .observeOn(Schedulers.trampoline())
                .subscribeOn(Schedulers.io())
                .subscribe(new QuerySubscriber() {
                    @Override
                    public void onQueryStart() {
                        System.err.printf("1.线程:[%s], 当前时间:[%s], 查询数据开始\n", getThreadName(), fmt(now()));
                    }

                    @Override
                    public void onSeriesStart(QueryResult.Series series, SimpleValueConverter c) {
                        System.err.printf("2.线程:[%s], 当前时间:[%s], 新的Series:[%s], size:[%d]\n",
                                getThreadName(), fmt(now()), series.hashCode(), series.getValues().size());
                    }

                    @Override
                    public void onSeriesNext(List<Object> values, SimpleValueConverter c, int position) {
                        counter.incrementAndGet();
                        buffer.append(counter.get()).append(", ")
                                .append(fmt(c.getDate())).append(", ")
                                .append(c.getInteger("point"))
                                .append("\n");
                    }

                    @Override
                    public void onSeriesComplete(QueryResult.Series series, SimpleValueConverter c) {
                        System.err.printf("3.线程:[%s], 当前时间:[%s], Series迭代完毕:[%s], size:[%d]\n",
                                getThreadName(), fmt(now()), series.hashCode(), series.getValues().size());
                    }

                    @Override
                    public void onQueryComplete() {
                        System.err.printf("4.线程:[%s], 当前时间:[%s], 查询数据结束\n", getThreadName(), fmt(now()));
                    }

                });

        long now = now();
        long spend = now - startTime;
        System.err.printf("5.线程:[%s], 当前时间:[%s], 使用时间:[%d], size:[%d]\n",
                getThreadName(), fmt(now), spend, counter.get());


        String data = buffer.toString();
        writeToFile("D:/test/abc.txt", data);
    }

    private void writeToFile(String filename, String data) {
        File file = new File(filename);
        file.getParentFile().mkdirs();
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            IOUtils.write(data, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static long now() {
        return System.currentTimeMillis();
    }

    private static String getThreadName() {
        return Thread.currentThread().getName();
    }
}
