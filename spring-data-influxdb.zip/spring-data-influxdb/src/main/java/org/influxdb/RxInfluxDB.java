package org.influxdb;

import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;
import org.influxdb.dto.Query;
import org.influxdb.dto.QueryResult;

import java.util.concurrent.TimeUnit;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

/**
 * Interface with all available methods to access a InfluxDB database.
 * <p>
 * A full list of currently available interfaces is implemented in:
 * <p>
 * <a
 * href="https://github.com/influxdb/influxdb/blob/master/src/api/http/api.go">https://github.com/
 * influxdb/influxdb/blob/master/src/api/http/api.go</a>
 *
 * @author stefan.majer [at] gmail.com
 */
public interface RxInfluxDB extends InfluxDB {

    /**
     * Execute a query against a database.
     *
     * @param query the query to execute.
     * @return a List of Series which matched the query.
     */
    QueryResult query(final Query query);

    /**
     * Execute a query against a database.
     * <p>
     * One of the consumers will be executed.
     *
     * @param query     the query to execute.
     * @param onSuccess the consumer to invoke when result is received
     * @param onFailure the consumer to invoke when error is thrown
     */
    @Deprecated
    void query(final Query query, final Consumer<QueryResult> onSuccess, final Consumer<Throwable> onFailure);

    /**
     * Execute a streaming query against a database.
     *
     * @param query     the query to execute.
     * @param chunkSize the number of QueryResults to process in one chunk.
     * @param onNext    the consumer to invoke for each received QueryResult
     */
    @Deprecated
    void query(Query query, int chunkSize, Consumer<QueryResult> onNext);

    /**
     * Execute a streaming query against a database.
     *
     * @param query     the query to execute.
     * @param chunkSize the number of QueryResults to process in one chunk.
     * @param onNext    the consumer to invoke for each received QueryResult; with capability to discontinue a streaming query
     */
    @Deprecated
    void query(Query query, int chunkSize, BiConsumer<Cancellable, QueryResult> onNext);

    /**
     * Execute a streaming query against a database.
     *
     * @param query      the query to execute.
     * @param chunkSize  the number of QueryResults to process in one chunk.
     * @param onNext     the consumer to invoke for each received QueryResult
     * @param onComplete the onComplete to invoke for successfully end of stream
     */
    @Deprecated
    void query(Query query, int chunkSize, Consumer<QueryResult> onNext, Runnable onComplete);

    /**
     * Execute a streaming query against a database.
     *
     * @param query      the query to execute.
     * @param chunkSize  the number of QueryResults to process in one chunk.
     * @param onNext     the consumer to invoke for each received QueryResult; with capability to discontinue a streaming query
     * @param onComplete the onComplete to invoke for successfully end of stream
     */
    @Deprecated
    void query(Query query, int chunkSize, BiConsumer<Cancellable, QueryResult> onNext, Runnable onComplete);

    /**
     * Execute a streaming query against a database.
     *
     * @param query      the query to execute.
     * @param chunkSize  the number of QueryResults to process in one chunk.
     * @param onNext     the consumer to invoke for each received QueryResult; with capability to discontinue a streaming query
     * @param onComplete the onComplete to invoke for successfully end of stream
     * @param onFailure  the consumer for error handling
     */
    @Deprecated
    void query(Query query, int chunkSize, BiConsumer<Cancellable, QueryResult> onNext, Runnable onComplete,
               Consumer<Throwable> onFailure);

    /**
     * Execute a query against a database.
     *
     * @param query    the query to execute.
     * @param timeUnit the time unit of the results.
     * @return a List of Series which matched the query.
     */
    QueryResult query(final Query query, TimeUnit timeUnit);

    /**
     * Execute a query against a database.
     *
     * @param query the query to execute.
     * @return a List of Series which matched the query.
     */
    Flowable<QueryResult> queryForRx(final Query query, BackpressureStrategy strategy);

    /**
     * Execute a query against a database.
     *
     * @param query    the query to execute.
     * @param timeUnit the time unit of the results.
     * @return a List of Series which matched the query.
     */
    Flowable<QueryResult> queryForRx(final Query query, TimeUnit timeUnit, BackpressureStrategy strategy);

    /**
     * Execute a query against a database.
     *
     * @param query     the query to execute.
     * @param chunkSize the number of QueryResults to process in one chunk.
     * @param strategy  反压策略
     * @return a List of Series which matched the query.
     */
    Flowable<QueryResult> queryForRx(Query query, int chunkSize, BackpressureStrategy strategy);

}
