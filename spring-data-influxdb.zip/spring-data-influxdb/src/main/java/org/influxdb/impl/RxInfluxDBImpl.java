package org.influxdb.impl;


import com.squareup.moshi.JsonAdapter;
import com.squareup.moshi.Moshi;
import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;
import okhttp3.OkHttpClient;
import okhttp3.ResponseBody;
import okio.BufferedSource;
import org.influxdb.InfluxDBException;
import org.influxdb.RxInfluxDB;
import org.influxdb.dto.BoundParameterQuery;
import org.influxdb.dto.Query;
import org.influxdb.dto.QueryResult;
import org.influxdb.msgpack.MessagePackTraverser;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.util.Iterator;
import java.util.concurrent.TimeUnit;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

/**
 * Implementation of a InluxDB API.
 *
 * @author stefan.majer [at] gmail.com
 */
public class RxInfluxDBImpl extends InfluxDBImpl implements RxInfluxDB {

    private InfluxDBService influxDBService;
    private ChunkProccesor chunkProccesor;

    public RxInfluxDBImpl(String url, String username, String password, OkHttpClient.Builder client) {
        this(url, username, password, client, ResponseFormat.JSON);
    }

    public RxInfluxDBImpl(String url, String username, String password, OkHttpClient.Builder okHttpBuilder, ResponseFormat responseFormat) {
        this(url, username, password, okHttpBuilder, new retrofit2.Retrofit.Builder(), responseFormat);
    }

    public RxInfluxDBImpl(String url, String username, String password, OkHttpClient.Builder okHttpBuilder, Retrofit.Builder retrofitBuilder, ResponseFormat responseFormat) {
        super(url, username, password, okHttpBuilder, retrofitBuilder, responseFormat);
        switch (responseFormat) {
            case MSGPACK:
                chunkProccesor = new MessagePackChunkProccesor();
                break;
            case JSON:
            default:
                Moshi moshi = new Moshi.Builder().build();
                JsonAdapter<QueryResult> adapter = moshi.adapter(QueryResult.class);
                chunkProccesor = new JSONChunkProccesor(adapter);
                break;
        }
    }

    protected InfluxDBService getInfluxDBService() {
        if (this.influxDBService == null) {
            synchronized (this) {
                Class<?> superclass = getClass().getSuperclass();
                while (superclass != InfluxDBImpl.class && superclass != Object.class) {
                    superclass = superclass.getSuperclass();
                }
                if (superclass == InfluxDBImpl.class) {
                    this.influxDBService = getFieldValue(superclass, "influxDBService", this);
                }

                if (this.influxDBService == null) {
                    throw new IllegalStateException("无法获取InfluxDBService对象");
                }
            }
        }
        return this.influxDBService;
    }

    protected ChunkProccesor getChunkProccesor() {
        return this.chunkProccesor;
    }

    /**
     * Execute a streaming query against a database.
     *
     * @param query      the query to execute.
     * @param chunkSize  the number of QueryResults to process in one chunk.
     * @param onNext     the consumer to invoke for each received QueryResult; with capability to discontinue a streaming query
     * @param onComplete the onComplete to invoke for successfully end of stream
     * @param onFailure  the consumer for error handling
     */
    @Deprecated
    @Override
    public void query(Query query, int chunkSize, BiConsumer<Cancellable, QueryResult> onNext, Runnable onComplete, Consumer<Throwable> onFailure) {
        Call<ResponseBody> call = callResponseBody(query, chunkSize);
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(final Call<ResponseBody> call, final Response<ResponseBody> response) {

                Cancellable cancellable = new Cancellable() {
                    @Override
                    public void cancel() {
                        call.cancel();
                    }

                    @Override
                    public boolean isCanceled() {
                        return call.isCanceled();
                    }
                };

                try {
                    if (response.isSuccessful()) {
                        ResponseBody chunkedBody = response.body();
                        getChunkProccesor().process(chunkedBody, cancellable, onNext, onComplete);
                    } else {
                        // REVIEW: must be handled consistently with IOException.
                        ResponseBody errorBody = response.errorBody();
                        if (errorBody != null) {
                            InfluxDBException influxDBException = new InfluxDBException(errorBody.string());
                            if (onFailure == null) {
                                throw influxDBException;
                            } else {
                                onFailure.accept(influxDBException);
                            }
                        }
                    }
                } catch (IOException e) {
                    QueryResult queryResult = new QueryResult();
                    queryResult.setError(e.toString());
                    onNext.accept(cancellable, queryResult);
                    //passing null onFailure consumer is here for backward compatibility
                    //where the empty queryResult containing error is propagating into onNext consumer
                    if (onFailure != null) {
                        onFailure.accept(e);
                    }
                }
            }

            @Override
            public void onFailure(final Call<ResponseBody> call, final Throwable t) {
                if (onFailure == null) {
                    throw new InfluxDBException(t);
                } else {
                    onFailure.accept(t);
                }
            }
        });
    }

    /**
     * Execute a query against a database.
     *
     * @param query the query to execute.
     * @return a List of Series which matched the query.
     */
    @Override
    public Flowable<QueryResult> queryForRx(Query query, BackpressureStrategy strategy) {
        return Flowable.create(emitter -> {
            try {
                QueryResult result = query(query);
                emitter.onNext(result);
                emitter.onComplete();
            } catch (Exception e) {
                emitter.onError(e);
            }
        }, strategy);
    }

    /**
     * Execute a query against a database.
     *
     * @param query    the query to execute.
     * @param timeUnit the time unit of the results.
     * @return a List of Series which matched the query.
     */
    @Override
    public Flowable<QueryResult> queryForRx(Query query, TimeUnit timeUnit, BackpressureStrategy strategy) {
        return Flowable.create(emitter -> {
            try {
                QueryResult result = query(query, timeUnit);
                emitter.onNext(result);
                emitter.onComplete();
            } catch (Exception e) {
                emitter.onError(e);
            }
        }, strategy);
    }

    /**
     * Execute a query against a database.
     *
     * @param query     the query to execute.
     * @param chunkSize the number of QueryResults to process in one chunk.
     * @param strategy  反压策略
     * @return a List of Series which matched the query.
     */
    @Override
    public Flowable<QueryResult> queryForRx(Query query, int chunkSize, BackpressureStrategy strategy) {
        return Flowable.create(emitter -> {
            Call<ResponseBody> call = callResponseBody(query, chunkSize);

            Response<ResponseBody> response = call.execute();
            Cancellable cancellable = new Cancellable() {
                @Override
                public void cancel() {
                    call.cancel();
                }

                @Override
                public boolean isCanceled() {
                    return call.isCanceled();
                }
            };

            try {
                if (response.isSuccessful()) {
                    ResponseBody chunkedBody = response.body();
                    getChunkProccesor().process(chunkedBody, cancellable, (cancellable1, result) -> emitter.onNext(result), emitter::onComplete);
                } else {
                    // REVIEW: must be handled consistently with IOException.
                    ResponseBody errorBody = response.errorBody();
                    if (errorBody != null) {
                        emitter.onError(new InfluxDBException(errorBody.string()));
                    }
                }
            } catch (IOException e) {
                QueryResult queryResult = new QueryResult();
                queryResult.setError(e.toString());
                emitter.onNext(queryResult);
                //passing null onFailure consumer is here for backward compatibility
                //where the empty queryResult containing error is propagating into onNext consumer
                emitter.onError(e);
            }
        }, strategy);
    }

    /**
     * Calls the influxDBService for the query.
     */
    protected Call<QueryResult> callQuery(final Query query, TimeUnit timeUnit) {
        String database = query.getDatabase();
        String command = query.getCommandWithUrlEncoded();
        Call<QueryResult> call;
        String epoch = timeUnit != null ? TimeUtil.toTimePrecision(timeUnit) : null;
        if (query instanceof BoundParameterQuery) {
            String parameter = ((BoundParameterQuery) query).getParameterJsonWithUrlEncoded();
            if (timeUnit != null) {
                call = this.getInfluxDBService().query(database, epoch, command, parameter);
            } else {
                call = this.getInfluxDBService().postQuery(database, command, parameter);
            }
        } else {
            if (query.requiresPost()) {
                if (timeUnit != null) {
                    call = this.getInfluxDBService().postQuery(database, epoch, command);
                } else {
                    call = this.getInfluxDBService().postQuery(database, command);
                }
            } else {
                if (timeUnit != null) {
                    call = this.getInfluxDBService().query(database, epoch, command);
                } else {
                    call = this.getInfluxDBService().query(database, command);
                }
            }
        }
        return call;
    }

    /**
     * Calls the influxDBService for the query.
     */
    protected Call<ResponseBody> callResponseBody(final Query query, int chunkSize) {
        Call<ResponseBody> call;
        String command = query.getCommandWithUrlEncoded();
        String database = query.getDatabase();
        if (query instanceof BoundParameterQuery) {
            BoundParameterQuery bpq = (BoundParameterQuery) query;
            call = getInfluxDBService().query(database, command, chunkSize,
                    bpq.getParameterJsonWithUrlEncoded());
        } else {
            call = this.getInfluxDBService().query(database, command, chunkSize);
        }
        return call;
    }

    @SuppressWarnings("unchecked")
    private <T> T getFieldValue(Class<?> clazz, String fieldName, Object o) {
        try {
            Field field = clazz.getDeclaredField(fieldName);
            if (field != null) {
                field.setAccessible(true);
                return (T) field.get(o);
            }
        } catch (NoSuchFieldException | IllegalAccessException e) {
            e.printStackTrace();
        }
        return null;
    }


    protected interface ChunkProccesor {
        void process(ResponseBody chunkedBody, Cancellable cancellable,
                     BiConsumer<Cancellable, QueryResult> consumer, Runnable onComplete) throws IOException;
    }

    protected static class MessagePackChunkProccesor implements ChunkProccesor {
        @Override
        public void process(final ResponseBody chunkedBody, final Cancellable cancellable,
                            final BiConsumer<Cancellable, QueryResult> consumer, final Runnable onComplete)
                throws IOException {
            MessagePackTraverser traverser = new MessagePackTraverser();
            try (InputStream is = chunkedBody.byteStream()) {
                for (Iterator<QueryResult> it = traverser.traverse(is).iterator(); it.hasNext() && !cancellable.isCanceled(); ) {
                    QueryResult result = it.next();
                    consumer.accept(cancellable, result);
                }
            }
            if (!cancellable.isCanceled()) {
                onComplete.run();
            }
        }
    }

    protected static class JSONChunkProccesor implements ChunkProccesor {
        private JsonAdapter<QueryResult> adapter;

        public JSONChunkProccesor(final JsonAdapter<QueryResult> adapter) {
            this.adapter = adapter;
        }

        @Override
        public void process(final ResponseBody chunkedBody, final Cancellable cancellable,
                            final BiConsumer<Cancellable, QueryResult> consumer, final Runnable onComplete)
                throws IOException {
            try {
                BufferedSource source = chunkedBody.source();
                while (!cancellable.isCanceled()) {
                    QueryResult result = adapter.fromJson(source);
                    if (result != null) {
                        consumer.accept(cancellable, result);
                    }
                }
            } catch (EOFException e) {
                QueryResult queryResult = new QueryResult();
                queryResult.setError("DONE");
                consumer.accept(cancellable, queryResult);
                if (!cancellable.isCanceled()) {
                    onComplete.run();
                }
            } finally {
                chunkedBody.close();
            }
        }
    }
}
