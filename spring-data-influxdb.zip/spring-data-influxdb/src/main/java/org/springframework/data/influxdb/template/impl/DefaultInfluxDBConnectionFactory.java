package org.springframework.data.influxdb.template.impl;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import org.influxdb.InfluxDB;
import org.influxdb.InfluxDBFactory;
import org.springframework.data.influxdb.InfluxDBProperties;
import org.springframework.data.influxdb.converter.PointConverterFactory;
import org.springframework.data.influxdb.template.AbstractInfluxDBConnectionFactory;

/**
 * 默认InfluxDBTemplateFactory实现
 */
public class DefaultInfluxDBConnectionFactory extends AbstractInfluxDBConnectionFactory<InfluxDB> {

    public DefaultInfluxDBConnectionFactory() {
    }

    public DefaultInfluxDBConnectionFactory(InfluxDBProperties properties,
                                            PointConverterFactory converterFactory,
                                            Interceptor networkInterceptor) {
        super(properties, converterFactory, networkInterceptor);
    }

    /**
     * 创建新的InfluxDB实现对象
     *
     * @param url      URL 地址
     * @param username 用户名
     * @param password 密码
     * @param client   OkHttp的Builder
     * @return 返回新创建的InfluxDB对象
     */
    @Override
    public InfluxDB newInfluxDB(String url, String username, String password, OkHttpClient.Builder client) {
        return InfluxDBFactory.connect(url, username, password, client);
    }
}
