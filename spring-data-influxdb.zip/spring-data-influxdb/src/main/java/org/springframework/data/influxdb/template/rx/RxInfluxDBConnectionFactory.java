package org.springframework.data.influxdb.template.rx;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import org.influxdb.RxInfluxDB;
import org.influxdb.RxInfluxDBFactory;
import org.springframework.data.influxdb.InfluxDBProperties;
import org.springframework.data.influxdb.converter.PointConverterFactory;
import org.springframework.data.influxdb.template.AbstractInfluxDBConnectionFactory;

/**
 * InfluxDBTemplateFactory的RxJava实现
 */
public class RxInfluxDBConnectionFactory extends AbstractInfluxDBConnectionFactory<RxInfluxDB> {


    public RxInfluxDBConnectionFactory() {
    }

    public RxInfluxDBConnectionFactory(InfluxDBProperties properties,
                                       PointConverterFactory converterFactory,
                                       Interceptor networkInterceptor) {
        super(properties, converterFactory, networkInterceptor);
    }

    @Override
    public RxInfluxDB newInfluxDB(String url, String username, String password, OkHttpClient.Builder client) {
        return RxInfluxDBFactory.connect(url, username, password, client);
    }
}
