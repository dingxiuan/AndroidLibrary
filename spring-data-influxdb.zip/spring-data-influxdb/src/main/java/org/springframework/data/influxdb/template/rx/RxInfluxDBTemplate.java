package org.springframework.data.influxdb.template.rx;

import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;
import org.influxdb.RxInfluxDB;
import org.influxdb.dto.Query;
import org.influxdb.dto.QueryResult;
import org.springframework.data.influxdb.template.AbstractInfluxDBTemplate;
import org.springframework.data.influxdb.template.InfluxDBConnectionFactory;

import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

/**
 * InfluxDBTemplate的RxJava实现
 */
public class RxInfluxDBTemplate extends AbstractInfluxDBTemplate<RxInfluxDB, Flowable<QueryResult>> {

    public RxInfluxDBTemplate() {
    }

    public RxInfluxDBTemplate(InfluxDBConnectionFactory<RxInfluxDB> connectionFactory) {
        super(connectionFactory);
    }

    /**
     * Executes a query against the database.
     *
     * @param query the query to execute
     * @return a List of time series data matching the query
     */
    @Override
    public Flowable<QueryResult> query(Query query) {
        return getInfluxDB().queryForRx(query, BackpressureStrategy.BUFFER);
    }

    /**
     * Executes a query against the database.
     *
     * @param query    the query to execute
     * @param timeUnit the time unit to be used for the query
     * @return a List of time series data matching the query
     */
    @Override
    public Flowable<QueryResult> query(Query query, TimeUnit timeUnit) {
        return getInfluxDB().queryForRx(query, timeUnit, BackpressureStrategy.BUFFER);
    }

    /**
     * Executes a query against the database.
     *
     * @param query     the query to execute
     * @param chunkSize the number of QueryResults to process in one chunk
     * @return a List of time series data matching the query
     */
    @Override
    public Flowable<QueryResult> query(Query query, int chunkSize) {
        return getInfluxDB().queryForRx(query, chunkSize, BackpressureStrategy.BUFFER);
    }

    /**
     *
     * deprecated: see {@link #query(Query, int)}
     *
     * Executes a query against the database.
     *
     * @param query     the query to execute
     * @param chunkSize the number of QueryResults to process in one chunk
     * @param consumer  consuming that the List of time series data matching the query
     */
    @Deprecated
    @Override
    public void query(Query query, int chunkSize, Consumer<QueryResult> consumer) throws IllegalStateException {
        getInfluxDB().query(query, chunkSize, consumer);
    }
}
