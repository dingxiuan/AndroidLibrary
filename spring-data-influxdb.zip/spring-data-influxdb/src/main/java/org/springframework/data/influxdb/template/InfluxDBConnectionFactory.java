package org.springframework.data.influxdb.template;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import org.influxdb.InfluxDB;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.data.influxdb.InfluxDBProperties;
import org.springframework.data.influxdb.converter.PointConverterFactory;

/**
 *
 */
public interface InfluxDBConnectionFactory<Influx extends InfluxDB> extends InitializingBean {

    /**
     * 创建新的InfluxDB实现对象
     *
     * @param url      URL 地址
     * @param username 用户名
     * @param password 密码
     * @param client   OkHttp的Builder
     * @return 返回新创建的InfluxDB对象
     */
    Influx newInfluxDB(String url, String username, String password, OkHttpClient.Builder client);

    /**
     * 获取InfluxDB实现对象
     */
    Influx getInfluxDB();

    /**
     * InfluxDB的配置
     */
    InfluxDBProperties getInfluxDBProperties();

    /**
     * 转换Bean为Point的转换器工厂
     */
    PointConverterFactory getConverterFactory();

    /**
     * 网络拦截器
     */
    Interceptor getNetworkInterceptor();

}
