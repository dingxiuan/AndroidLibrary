/*
 * Copyright 2016 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.springframework.data.influxdb.template;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import org.influxdb.InfluxDB;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.influxdb.InfluxDBProperties;
import org.springframework.data.influxdb.converter.PointConverterFactory;
import org.springframework.util.Assert;

import java.util.concurrent.TimeUnit;

public abstract class AbstractInfluxDBConnectionFactory<Influx extends InfluxDB>
        implements InfluxDBConnectionFactory<Influx> {

    protected static Logger logger = LoggerFactory.getLogger(AbstractInfluxDBConnectionFactory.class);

    /**
     * InfluxDB的连接
     */
    private volatile Influx influxDB;

    /**
     * InfluxDB的属性配置
     */
    private InfluxDBProperties properties;
    /**
     * 将Bean转换为Point的转换器工厂
     */
    private PointConverterFactory converterFactory;
    /**
     * OkHttp的网络请求拦截器
     */
    private Interceptor networkInterceptor;


    public AbstractInfluxDBConnectionFactory() {
        // ~
    }

    public AbstractInfluxDBConnectionFactory(InfluxDBProperties properties,
                                             PointConverterFactory converterFactory,
                                             Interceptor networkInterceptor) {
        setInfluxDBProperties(properties);
        setConverterFactory(converterFactory);
       setNetworkInterceptor(networkInterceptor);
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        Assert.notNull(getInfluxDBProperties(), "InfluxDBProperties are required");
    }

    @Override
    public Influx getInfluxDB() {
        if (influxDB == null) {
            Influx influxDB = this.influxDB;
            final InfluxDBProperties properties = getInfluxDBProperties();
            Assert.notNull(properties, "InfluxDBProperties are required");
            synchronized (this) {
                if (influxDB != null) {
                    return influxDB;
                }
                final OkHttpClient.Builder client = new OkHttpClient.Builder()
                        .connectTimeout(properties.getConnectTimeout(), TimeUnit.SECONDS)
                        .writeTimeout(properties.getWriteTimeout(), TimeUnit.SECONDS)
                        .readTimeout(properties.getReadTimeout(), TimeUnit.SECONDS);

                final Interceptor networkInterceptor = getNetworkInterceptor();
                // 添加网络过滤器
                if (networkInterceptor != null) {
                    client.addNetworkInterceptor(networkInterceptor);
                }
                String url = properties.getUrl();
                String username = properties.getUsername();
                String password = properties.getPassword();
                influxDB = newInfluxDB(url, username, password, client);

                logger.debug("Using InfluxDB '{}' on '{}'", properties.getDatabase(), url);

                if (properties.isGzip()) {
                    logger.debug("Enabled gzip compression for HTTP requests");
                    influxDB.enableGzip();
                }

                this.influxDB = influxDB;
            }
        }
        return influxDB;
    }

    /**
     * Returns the configuration properties.
     *
     * @return Returns the configuration properties
     */
    @Override
    public InfluxDBProperties getInfluxDBProperties() {
        return properties;
    }

    /**
     * Sets the configuration properties.
     *
     * @param properties The configuration properties to set
     */
    public void setInfluxDBProperties(final InfluxDBProperties properties) {
        this.properties = properties;
    }

    /**
     * 转换Bean
     */
    @Override
    public PointConverterFactory getConverterFactory() {
        return converterFactory;
    }

    public void setConverterFactory(PointConverterFactory converterFactory) {
        this.converterFactory = converterFactory;
    }

    @Override
    public Interceptor getNetworkInterceptor() {
        return networkInterceptor;
    }

    public void setNetworkInterceptor(Interceptor networkInterceptor) {
        this.networkInterceptor = networkInterceptor;
    }
}
