package org.springframework.data.influxdb.template.rx;

import io.reactivex.FlowableSubscriber;
import org.influxdb.dto.QueryResult;
import org.reactivestreams.Subscription;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.influxdb.query.QueryConsumer;
import org.springframework.data.influxdb.query.SimpleValueConverter;

import java.util.List;

/**
 * 查询的消费者
 */
public abstract class QuerySubscriber implements
        FlowableSubscriber<QueryResult>, QueryConsumer<SimpleValueConverter> {

    private static final Logger LOGGER = LoggerFactory.getLogger(QuerySubscriber.class);

    private Subscription subscription;
    private SimpleValueConverter converter;

    public QuerySubscriber() {
    }

    @Override
    public final void onSubscribe(Subscription subscription) {
        this.subscription = subscription;
        this.onQueryStart();
        this.subscription.request(1);
    }

    @Override
    public final void onNext(QueryResult result) {
        if (!result.hasError()) {
            this.onResultNext(result);
        } else {
            LOGGER.info("result error: {}", result.getError());
        }
        this.subscription.request(1);
    }

    @Override
    public final void onError(Throwable e) {
        this.onQueryError(e);
    }

    @Override
    public final void onComplete() {
        this.onQueryComplete();
    }

    /**
     * 取消
     */
    public final void cancel() {
        if (subscription != null) {
            subscription.cancel();
            this.onQueryCancel();
        }
    }


    /*****************************************/
    // QueryConsumer

    /**
     * 查询开始
     */
    @Override
    public void onQueryStart() {
        // ~
    }

    @Override
    public final void onResultNext(QueryResult result) {
        result.getResults()
                .stream()
                .filter(RESULT_FILTER)
                .flatMap(SERIES_STREAM)
                .forEach(this::iterator);
    }

    /**
     * 查询完成
     */
    @Override
    public void onQueryComplete() {
        // ~
    }

    /**
     * 查询被取消时
     */
    @Override
    public void onQueryCancel() {
        // ~
    }

    /**
     * 查询出现异常
     *
     * @param e
     */
    @Override
    public void onQueryError(Throwable e) {
        e.printStackTrace();
    }

    /**
     * 当新的Series开始时
     *
     * @param series 序列
     * @param c      转换器对象
     */
    @Override
    public void onSeriesStart(QueryResult.Series series, SimpleValueConverter c) {
        // ~
    }

    /**
     * 迭代Series的下一个值
     *
     * @param values    值
     * @param converter 转换器对象
     * @param position  当前值的位置
     */
    @Override
    public abstract void onSeriesNext(List<Object> values, SimpleValueConverter converter, int position);

    /**
     * 迭代Series的完成
     *
     * @param series 序列
     * @param c      转换器对象
     */
    @Override
    public void onSeriesComplete(QueryResult.Series series, SimpleValueConverter c) {
        // ~
    }

    /**
     * 获取 SeriesConverter
     */
    @Override
    public final SimpleValueConverter getConverter() {
        if (converter == null) {
            synchronized (this) {
                if (converter != null) {
                    return converter;
                }
                converter = new SimpleValueConverter();
            }
        }
        return converter;
    }


    public final void iterator(QueryResult.Series series) {
        final SimpleValueConverter c = this.getConverter();
        int position = c.getPosition();
        c.setupSeries(series);
        this.onSeriesStart(series, c);
        int size = c.getValues().size();
        for (int i = 0; i < size; i++) {
            c.setPosition(i);
            this.onSeriesNext(c.getValue(i), c, i);
        }
        this.onSeriesComplete(series, c);
        c.setPosition(position);
    }
}
