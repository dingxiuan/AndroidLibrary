/*
 * Copyright 2016 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.springframework.data.influxdb.template;

import org.influxdb.InfluxDB;
import org.influxdb.RxInfluxDB;
import org.influxdb.dto.BatchPoints;
import org.influxdb.dto.Pong;
import org.influxdb.dto.Query;
import org.influxdb.dto.QueryResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.influxdb.InfluxDBProperties;
import org.springframework.data.influxdb.converter.PointConverterFactory;
import org.springframework.util.Assert;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * 抽象的InfluxDBTemplate实现
 */
public abstract class AbstractInfluxDBTemplate<Influx extends InfluxDB, Q>
        implements InfluxDBTemplate<Influx, Q> {

    protected final Logger logger = LoggerFactory.getLogger(getClass());

    private InfluxDBConnectionFactory<Influx> connectionFactory;

    public AbstractInfluxDBTemplate() {
        // ~
    }

    public AbstractInfluxDBTemplate(InfluxDBConnectionFactory<Influx> connectionFactory) {
        setConnectionFactory(connectionFactory);
    }

    @Override
    public void afterPropertiesSet() {
        Assert.notNull(getConnectionFactory(), "InfluxDBConnectionFactory is required");
        Assert.notNull(getConverterFactory(), "PointConverterFactory is required");
    }

    public void setConnectionFactory(final InfluxDBConnectionFactory<Influx> connectionFactory) {
        this.connectionFactory = connectionFactory;
    }

    @Override
    public InfluxDBConnectionFactory<Influx> getConnectionFactory() {
        return connectionFactory;
    }

    @Override
    public InfluxDBProperties getInfluxDbProperties() {
        return getConnectionFactory().getInfluxDBProperties();
    }

    /**
     * 获取Point转换器工厂
     *
     * @return PointConverterFactory
     */
    @Override
    public PointConverterFactory getConverterFactory() {
        return getConnectionFactory().getConverterFactory();
    }

    @Override
    public Influx getInfluxDB() {
        return getConnectionFactory().getInfluxDB();
    }

    @Override
    public String getDatabase() {
        return getInfluxDbProperties().getDatabase();
    }

    @Override
    public String getRetentionPolicy() {
        return getInfluxDbProperties().getRetentionPolicy();
    }

    @Override
    public void createDatabase() {
        final String database = getDatabase();
        //getRxInfluxDB().createDatabase(database);
        Query query = new Query("CREATE DATABASE", database);
        QueryResult result = getInfluxDB().query(query);
        logger.debug("create database result: {}", result);
    }

    /**
     * Write a single measurement to the database.
     *
     * @param payload the measurement to write to
     */
    @Override
    public <T> void write(T payload) {
        this.write(Collections.singletonList(payload));
    }

    @Override
    public final <T> void write(final T[] payload) {
        this.write(Arrays.asList(payload));
    }

    @Override
    public <T> void write(final List<T> payload) {
        if (payload == null || payload.isEmpty()) {
            return;
        }

        // 检查对象是否为null
        payload.forEach(t -> {
            if (t == null) {
                throw new NullPointerException("无法插入Null值");
            }
        });

        final String database = getDatabase();
        final String retentionPolicy = getRetentionPolicy();
        final BatchPoints ops = BatchPoints.database(database)
                .retentionPolicy(retentionPolicy)
                .consistency(RxInfluxDB.ConsistencyLevel.ALL)
                .build();
        payload.forEach(t -> ops.point(getConverterFactory().convert(t)));
        getInfluxDB().write(ops);
    }

    @Override
    public Pong ping() {
        return getInfluxDB().ping();
    }

    @Override
    public String version() {
        return getInfluxDB().version();
    }


}
