package org.springframework.data.influxdb.template.impl;

import org.influxdb.InfluxDB;
import org.influxdb.dto.Query;
import org.influxdb.dto.QueryResult;
import org.springframework.data.influxdb.template.AbstractInfluxDBTemplate;
import org.springframework.data.influxdb.template.InfluxDBConnectionFactory;

import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

/**
 * 默认的Template
 */
public class DefaultInfluxDBTemplate extends AbstractInfluxDBTemplate<InfluxDB, QueryResult> {

    public DefaultInfluxDBTemplate() {
    }

    public DefaultInfluxDBTemplate(InfluxDBConnectionFactory<InfluxDB> connectionFactory) {
        super(connectionFactory);
    }

    /**
     * Executes a query against the database.
     *
     * @param query the query to execute
     * @return a List of time series data matching the query
     */
    @Override
    public QueryResult query(Query query) {
        return getInfluxDB().query(query);
    }

    /**
     * Executes a query against the database.
     *
     * @param query    the query to execute
     * @param timeUnit the time unit to be used for the query
     * @return a List of time series data matching the query
     */
    @Override
    public QueryResult query(Query query, TimeUnit timeUnit) {
        return getInfluxDB().query(query, timeUnit);
    }

    /**
     * Executes a query against the database.
     *
     * @param query     the query to execute
     * @param chunkSize the number of QueryResults to process in one chunk
     * @return a List of time series data matching the query
     */
    @Deprecated
    @Override
    public QueryResult query(Query query, int chunkSize) throws IllegalStateException {
        throw new IllegalStateException("Not implements!");
        // 请使用其他的方法
    }

    /**
     * Executes a query against the database.
     *
     * @param query     the query to execute
     * @param chunkSize the number of QueryResults to process in one chunk
     * @param consumer  consumer
     * @return a List of time series data matching the query
     */
    @Override
    public void query(Query query, int chunkSize, Consumer<QueryResult> consumer) {
        getInfluxDB().query(query, chunkSize, consumer);
    }
}
