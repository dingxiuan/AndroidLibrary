/*
 * Copyright 2016 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.springframework.data.influxdb.template;

import org.influxdb.InfluxDB;
import org.influxdb.dto.Pong;
import org.influxdb.dto.Query;
import org.influxdb.dto.QueryResult;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.data.influxdb.InfluxDBProperties;
import org.springframework.data.influxdb.converter.PointConverterFactory;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

public interface InfluxDBTemplate<Influx extends InfluxDB, Q> extends InitializingBean {

    /**
     * 获取InfluxDB
     */
    Influx getInfluxDB();

    /**
     * InfluxDB连接工厂
     */
    InfluxDBConnectionFactory<Influx> getConnectionFactory();

    /**
     * InfluxDB的配置
     */
    InfluxDBProperties getInfluxDbProperties();

    /**
     * 获取Point转换器工厂
     *
     * @return PointConverterFactory
     */
    PointConverterFactory getConverterFactory();

    /**
     * Ensures that the configured database exists.
     */
    void createDatabase();

    /**
     * 数据库名
     */
    String getDatabase();

    /**
     * 缓存策略
     */
    String getRetentionPolicy();

    /**
     * Write a single measurement to the database.
     *
     * @param payload the measurement to write to
     */
    <T> void write(final T payload);

    /**
     * Write a single measurement to the database.
     *
     * @param payload the measurement to write to
     */
    <T> void write(final T[] payload);

    /**
     * Write a set of measurements to the database.
     *
     * @param payload the values to write to
     */
    <T> void write(final List<T> payload);

    /**
     * Executes a query against the database.
     *
     * @param query the query to execute
     * @return a List of time series data matching the query
     */
    Q query(final Query query);

    /**
     * Executes a query against the database.
     *
     * @param query    the query to execute
     * @param timeUnit the time unit to be used for the query
     * @return a List of time series data matching the query
     */
    Q query(final Query query, final TimeUnit timeUnit);

    /**
     * Executes a query against the database.
     *
     * @param query     the query to execute
     * @param chunkSize the number of QueryResults to process in one chunk
     * @return a List of time series data matching the query
     */
    Q query(Query query, int chunkSize) throws IllegalStateException;

    /**
     * Executes a query against the database.
     *
     * @param query     the query to execute
     * @param chunkSize the number of QueryResults to process in one chunk
     * @param consumer  consumer
     */
    void query(Query query, int chunkSize, Consumer<QueryResult> consumer) throws IllegalStateException;

    /**
     * Ping the database.
     *
     * @return the response of the ping execution
     */
    Pong ping();

    /**
     * Return the version of the connected database.
     *
     * @return the version String, otherwise unknown
     */
    String version();
}
