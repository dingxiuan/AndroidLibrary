/*
 * Copyright 2016 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.springframework.data.influxdb.enable;

import io.reactivex.Observable;
import okhttp3.Interceptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.influxdb.InfluxDBProperties;
import org.springframework.data.influxdb.converter.DefaultPointConverterFactory;
import org.springframework.data.influxdb.converter.PointConverterFactory;
import org.springframework.data.influxdb.template.InfluxDBTemplate;
import org.springframework.data.influxdb.template.InfluxDBConnectionFactory;
import org.springframework.data.influxdb.template.impl.DefaultInfluxDBTemplate;
import org.springframework.data.influxdb.template.impl.DefaultInfluxDBConnectionFactory;
import org.springframework.data.influxdb.template.rx.RxInfluxDBConnectionFactory;
import org.springframework.data.influxdb.template.rx.RxInfluxDBTemplate;

@Configuration
public class InfluxDBConfiguration {

    private static Logger logger = LoggerFactory.getLogger("InfluxDB");

    @Bean
    @ConditionalOnMissingBean(InfluxDBConnectionFactory.class)
    public InfluxDBConnectionFactory templateFactory(InfluxDBProperties properties,
                                                     PointConverterFactory converterFactory,
                                                     @Autowired(required = false) Interceptor requestInfo) {
        InfluxDBConnectionFactory connectionFactory;
        if (supportRx(properties)) {
            connectionFactory = new RxInfluxDBConnectionFactory(properties, converterFactory, requestInfo);
        } else {
            connectionFactory = new DefaultInfluxDBConnectionFactory(properties, converterFactory, requestInfo);
        }
        return connectionFactory;
    }

    @Bean
    @ConditionalOnMissingBean(InfluxDBTemplate.class)
    public InfluxDBTemplate influxDBTemplate(InfluxDBConnectionFactory connectionFactory) {
        InfluxDBProperties properties = connectionFactory.getInfluxDBProperties();
        InfluxDBTemplate template;
        if (supportRx(properties)) {
            template = new RxInfluxDBTemplate(connectionFactory);
        } else {
            template = new DefaultInfluxDBTemplate(connectionFactory);
        }
        return template;
    }

    @Bean
    @ConditionalOnMissingBean(PointConverterFactory.class)
    public PointConverterFactory converterFactory() {
        return new DefaultPointConverterFactory();
    }


//    /**
//     * OkHttp的拦截器，主要用于打印日志
//     */
//    @Bean("requestInfo")
//    @ConditionalOnMissingBean(Interceptor.class)
//    public Interceptor requestInfo() {
//        return new NetworkInterceptor();
//    }


    /**
     * 是否支持响应式
     */
    protected boolean supportRx(InfluxDBProperties properties) {
        boolean support = properties.isReactiveX();
        if (!support) {
            try {
                Class.forName("io.reactivex.Observable");
            } catch (ClassNotFoundException e) {
                support = false;
            }
        }
        return support;
    }

}
