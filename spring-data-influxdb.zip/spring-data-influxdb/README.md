
Spring Data InfluxDB
--------------------

本项目改自[spring-data-influxdb]("https://github.com/miwurster/spring-data-influxdb")

## Artifacts

### Maven

```xml
<dependency>
  <groupId>com.github.miwurster</groupId>
  <artifactId>spring-data-influxdb</artifactId>
  <version>1.7</version>
</dependency>
```

## Usage (Spring Boot)

* Following properties can be used in your `application.yml`:

    ```yml
    spring:
      influxdb:
        url: http://localhost:8086
        username: user
        password: ~
        database: test-influxdb
        retention-policy: autogen
    ```
    
    Optionally, you can also configure connections, read, and write timeouts (in seconds):
    
    ```yml
    spring:
      influxdb:    	
        connect-timeout: 10
        read-timeout: 30
        write-timeout: 10
    ```

    Furthermore, one can enable gzip compression in order to reduce size of the transferred data:
    
    ```yml
    spring:
      influxdb:    	
        gzip: true
    ```

* Create `InfluxDBConnectionFactory` and `InfluxDBTemplate` beans:

    ```java
    @Configuration
    @EnableConfigurationProperties(InfluxDBProperties.class)
    public class InfluxDBConfiguration {
      @Bean
      public InfluxDBConnectionFactory connectionFactory(final InfluxDBProperties properties) {
        return new InfluxDBConnectionFactory(properties);
      }

      @Bean
      public InfluxDBTemplate<Point> influxDBTemplate(final InfluxDBConnectionFactory connectionFactory) {
        /*
         * You can use your own 'PointCollectionConverter' implementation, e.g. in case
         * you want to use your own custom measurement object.
         */
        return new InfluxDBTemplate<>(connectionFactory, new PointConverter());
      }
      
      @Bean
      public DefaultInfluxDBTemplate defaultTemplate(final InfluxDBConnectionFactory connectionFactory)
      {
        /*
         * If you are just dealing with Point objects from 'influxdb-java' you could
         * also use an instance of class DefaultInfluxDBTemplate.
         */
        return new DefaultInfluxDBTemplate(connectionFactory);
      }
    }
    ```

* Use `InfluxDBTemplate` to interact with the InfluxDB database:

    ```java
    @Autowired
    private InfluxDBTemplate<Point> influxDBTemplate;

    influxDBTemplate.createDatabase();
    final Point p = Point.measurement("disk")
      .time(System.currentTimeMillis(), TimeUnit.MILLISECONDS)
      .tag("tenant", "default")
      .addField("used", 80L)
      .addField("free", 1L)
      .build();
    influxDBTemplate.write(p);
    ```

## Building

Spring Data InfluxDB uses Maven as its build system. 

```bash
mvn clean install
```
