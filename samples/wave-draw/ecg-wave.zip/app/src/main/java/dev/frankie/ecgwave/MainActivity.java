package dev.frankie.ecgwave;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Timer;
import java.util.TimerTask;

import dev.frankie.view.EcgSurfaceView;

public class MainActivity extends AppCompatActivity {

    private List<Integer> datas = new ArrayList<Integer>();

    private Queue<Integer> data0Q = new LinkedList<Integer>();
    private Queue<Integer> data1Q = new LinkedList<Integer>();


    EcgSurfaceView ecgWaveView;
//    EcgView ecgWaveView;
    private Timer timer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ecgWaveView = findViewById(R.id.ecg_wave_view);

        simulator();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        timer.cancel();
    }

    /**
     * 模拟心电发送，心电数据是一秒500个包，所以
     */
    private void simulator(){
        timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                loadData();
                cancel();
            }
        }, 0, 1);
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                if(ecgWaveView.isRunning()){
                    if(data0Q.size() > 0){
                        ecgWaveView.addEcgData0(data0Q.poll());
                        ecgWaveView.addEcgData1(data1Q.poll());
                    }
                }
            }
        }, 2000, 2);
    }

    private void loadData(){
        try{
            String data0 = "";
            InputStream in = getResources().openRawResource(R.raw.ecgdata);
            int length = in.available();
            byte [] buffer = new byte[length];
            in.read(buffer);
            data0 = new String(buffer);
            in.close();
            String[] data0s = data0.split(",");
            for(String str : data0s){
                datas.add(Integer.parseInt(str));
            }
            data0Q.addAll(datas);
            data1Q.addAll(datas);
        }catch (Exception e){}
    }

}
